text = "Python N21"
int1 = 0
int2 = 1
