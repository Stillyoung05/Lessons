# print(5 + 5)
# print(8 * 9)
# print(10 / 3 == 3.3333333333333335) # suhdfjkhbf-)
import os

# Define the string and integers to be written in each file
string = "Python N21"
integer1 = 0
integer2 = 1

# Loop to create 20 folders
for i in range(1, 21):
    # Create a new folder
    folder_name = f"Folder{i}"
    os.makedirs(folder_name, exist_ok=True)

    # Create 2 Python files in each folder
    for j in range(1, 3):
        file_name = os.path.join(folder_name, f"file{j}.py")

        # Write the string and integers into each file
        with open(file_name, 'w') as f:
            f.write(f'text = "{string}"\nint1 = {integer1}\nint2 = {integer2}\n')
