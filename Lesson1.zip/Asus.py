model = "Asus"
price = 300
age = 2
print(model, price, age)
